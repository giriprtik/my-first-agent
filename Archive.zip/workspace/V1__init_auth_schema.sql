CREATE TABLE user_account (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username      VARCHAR(50)  NOT NULL UNIQUE,
    email         VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role          VARCHAR(30)  NOT NULL DEFAULT 'PATIENT',
    enabled       BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    deleted_at    TIMESTAMPTZ,
    password_changed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    failed_login_attempts INT NOT NULL DEFAULT 0,
    locked_until  TIMESTAMPTZ,

    full_name     VARCHAR(100) NOT NULL,
    department    VARCHAR(50),
    license_number VARCHAR(50) UNIQUE,
    specialization VARCHAR(100)
);

CREATE INDEX idx_user_account_role ON user_account (role);
CREATE INDEX idx_user_account_email_lower ON user_account (LOWER(email));
CREATE INDEX idx_user_account_username_lower ON user_account (LOWER(username));

ALTER TABLE user_account 
ADD CONSTRAINT chk_user_role 
CHECK (role IN ('PATIENT', 'DOCTOR', 'NURSE', 'LABTECH', 'ADMIN'));

CREATE OR REPLACE FUNCTION update_user_account_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_user_account_updated_at
    BEFORE UPDATE ON user_account
    FOR EACH ROW
    EXECUTE FUNCTION update_user_account_timestamp();